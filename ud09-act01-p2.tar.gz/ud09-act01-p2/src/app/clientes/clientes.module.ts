export class Banco{
  constructor(
  public saldoBanco:number = 0
  ){}
 }