import { Component } from '@angular/core';
import { Banco } from '../clientes.module';

@Component({
  selector: 'app-listaclientes',
  templateUrl: './listaclientes.component.html',
  styleUrl: './listaclientes.component.css'
})
export class ListaclientesComponent {

}
