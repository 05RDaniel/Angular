import { Component } from '@angular/core';
import { Banco } from '../clientes.module';

@Component({
  selector: 'app-listaoperaciones',
  templateUrl: './listaoperaciones.component.html',
  styleUrl: './listaoperaciones.component.css'
})
export class ListaoperacionesComponent {

}
