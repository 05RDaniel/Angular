import { Component } from '@angular/core';
import { Banco } from '../clientes.module';

@Component({
  selector: 'app-cliente',
  templateUrl: './cliente.component.html',
  styleUrl: './cliente.component.css'
})
export class ClienteComponent {
  banco:Banco = new Banco
  saldoBanco:number = this.banco.saldoBanco
  numCliente:number = 1
}
