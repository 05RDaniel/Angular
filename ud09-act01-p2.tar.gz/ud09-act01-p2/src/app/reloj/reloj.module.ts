export class Reloj{
  constructor(
  public fecha:Date,
  public hora:string = fecha.getHours().toString().padStart(2,"0"),
  public minuto:string = fecha.getMinutes().toString().padStart(2,"0"),
  public segundo:string = fecha.getSeconds().toString().padStart(2,"0")
  ){}
 }