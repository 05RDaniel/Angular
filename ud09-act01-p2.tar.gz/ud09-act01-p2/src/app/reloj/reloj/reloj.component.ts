import { Component } from '@angular/core';
import { Reloj } from '../reloj.module';
@Component({
 selector: 'app-reloj',
 templateUrl: './reloj.component.html',
 styleUrl: './reloj.component.css'
})
export class RelojComponent {
 public reloj: Reloj = new Reloj(new Date());
 public hora:string = this.reloj.hora+':'+this.reloj.minuto+':'+this.reloj.segundo;
 ngOnInit(): void {
    this.mostrarHora();
 }
 mostrarHora(): void {
    setInterval(() => {
     this.reloj = new Reloj(new Date());
     this.hora = this.reloj.hora+':'+this.reloj.minuto+':'+this.reloj.segundo;
    }, 1000);
 }
}