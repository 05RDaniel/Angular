import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RelojComponent } from './reloj/reloj/reloj.component';
import { ClienteComponent } from './clientes/cliente/cliente.component';
import { ListaclientesComponent } from './clientes/listaclientes/listaclientes.component';
import { ListaoperacionesComponent } from './clientes/listaoperaciones/listaoperaciones.component';

@NgModule({
  declarations: [
    AppComponent,
    RelojComponent,
    ClienteComponent,
    ListaclientesComponent,
    ListaoperacionesComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
