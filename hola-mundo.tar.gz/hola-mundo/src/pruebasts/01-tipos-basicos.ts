const nombre:string = 'Dani';
let edad:number|'niño' = 19;
edad = 'niño';
const casado:boolean = false;

console.log({
    nombre, edad, casado
});