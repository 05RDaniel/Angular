function suma(a: number, b: number): number {
  return a + b;
}

const result = suma(5, 10);

console.log(result);

const sumaNumerosFlecha = (a: number, b: number): string => {
  return `${a+b}`;
};

const result2:string = sumaNumerosFlecha(1,2);
/* console.log({result2}); */

function multiplica (primer:number, segundo?:number,base:number=2){
  
}