import { bootstrapApplication } from '@angular/platform-browser';
import { appConfig } from './app/app.config';
import { AppComponent } from './app/app.component';
/* import './pruebasts/01-tipos-basicos' */
/* import './pruebasts/02-interface';*/
import './pruebasts/03-funciones';

bootstrapApplication(AppComponent, appConfig)
  .catch((err) => console.error(err));
