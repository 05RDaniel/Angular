export class Empleado{
    constructor(
    public nombre:string,
    public edad:number){}
   }