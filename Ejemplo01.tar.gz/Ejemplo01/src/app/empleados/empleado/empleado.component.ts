import { Component } from '@angular/core';
import { Empleado } from '../empleado';
@Component({
 selector: 'app-empleados-empleado',
 standalone: false,
 templateUrl: './empleado.component.html',
 styleUrl: './empleado.component.css'
})
export class EmpleadoComponent {
 public empleado1: Empleado = new Empleado('Javier', 25);
}