import { SueldoNetoPipe } from './sueldo-neto.pipe';

describe('SueldoNetoPipe', () => {
  it('create an instance', () => {
    const pipe = new SueldoNetoPipe();
    expect(pipe).toBeTruthy();
  });
});
