import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NominaComponent } from './components/nomina/nomina.component';
import { ListaComponent } from './components/lista/lista.component';
import { FormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    NominaComponent,
    ListaComponent
  ],
  imports: [
    CommonModule,
    FormsModule
  ],
  exports: [
    NominaComponent,
    ListaComponent
  ],
})
export class NominasModule { }
