import { Component } from '@angular/core';
import { Nomina } from '../../nomina';
@Component({
  selector: 'app-nominas-nomina',
  standalone: false,
  templateUrl: './nomina.component.html',
  styleUrl: './nomina.component.css'
})
export class NominaComponent {
    
}